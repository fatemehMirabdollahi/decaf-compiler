package codegen.discriptors;

public enum Type{Integer, Double, String, Boolean, Record, Array
}
