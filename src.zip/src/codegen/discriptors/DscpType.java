package codegen.discriptors;

public enum DscpType{funcion, record, variable, array}
