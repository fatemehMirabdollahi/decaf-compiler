package scanner;

public enum TokenType{keyword, id, integer, real, str_char, spChar, comment, op_punc, undefined, end,pc}
